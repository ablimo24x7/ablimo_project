import { ServiceEditor } from "@/components/admin/service-editor";

export default function NewServicePage() {
  return <ServiceEditor mode="create" />;
}