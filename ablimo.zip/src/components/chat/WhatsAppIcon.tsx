/**
 * The official WhatsApp mark, in one place.
 *
 * The chat widget renders the mark in three spots — the floating launcher
 * button, the channel list and the WhatsApp popup header — so the path lives
 * here instead of being copy-pasted into every component.
 *
 * The mark is painted with `currentColor`, which lets it inherit the white
 * of the green launcher button, the per-channel tint of the channel list and
 * the white header of the popup without extra variants.
 */

const WHATSAPP_PATH =
  "M16 2C8.268 2 2 8.268 2 16C2 18.73 2.784 21.282 4.14 23.444L2.5 29.5L8.746 27.892C10.838 29.172 13.332 29.914 16 29.914C23.732 29.914 30 23.646 30 15.914C30 8.182 23.732 2 16 2ZM16 27.53C13.626 27.53 11.436 26.862 9.58 25.702L9.176 25.448L5.474 26.402L6.46 22.802L6.182 22.366C4.94 20.404 4.286 18.118 4.286 15.914C4.286 9.518 9.538 4.286 16 4.286C22.462 4.286 27.714 9.518 27.714 15.914C27.714 22.31 22.462 27.53 16 27.53ZM22.428 19.34C22.078 19.164 20.354 18.318 20.034 18.202C19.712 18.084 19.478 18.026 19.246 18.376C19.012 18.726 18.342 19.514 18.138 19.746C17.934 19.98 17.73 20.01 17.38 19.834C17.03 19.66 15.904 19.29 14.566 18.098C13.526 17.17 12.822 16.026 12.618 15.676C12.414 15.326 12.596 15.138 12.772 14.964C12.93 14.808 13.122 14.558 13.298 14.354C13.472 14.15 13.53 14.004 13.648 13.77C13.764 13.538 13.706 13.334 13.618 13.158C13.53 12.984 12.83 11.262 12.538 10.564C12.254 9.884 11.968 9.978 11.752 9.968C11.548 9.958 11.314 9.958 11.082 9.958C10.848 9.958 10.468 10.046 10.148 10.396C9.826 10.746 8.922 11.59 8.922 13.312C8.922 15.032 10.176 16.694 10.35 16.928C10.526 17.16 12.784 20.732 16.326 22.204C17.168 22.554 17.824 22.77 18.336 22.934C19.182 23.202 19.952 23.164 20.562 23.072C21.242 22.97 22.658 22.214 22.95 21.398C23.242 20.582 23.242 19.882 23.154 19.736C23.066 19.59 22.834 19.514 22.428 19.34Z";

/** The WhatsApp mark as raw markup, painted with the inherited colour. */
export const WHATSAPP_SVG = `<svg viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="${WHATSAPP_PATH}" fill="currentColor"></path></svg>`;

interface WhatsAppIconProps {
  className?: string;
  style?: React.CSSProperties;
}

/** The WhatsApp mark as a React component. */
export function WhatsAppIcon({ className, style }: WhatsAppIconProps) {
  return (
    <svg
      className={className}
      style={style}
      viewBox="0 0 32 32"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
      focusable="false"
    >
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d={WHATSAPP_PATH}
        fill="currentColor"
      />
    </svg>
  );
}
