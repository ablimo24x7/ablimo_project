"use client";

import { useState } from "react";
import { trackEvent } from "@/lib/analytics";

interface WidgetConfig {
  whatsappPopupHeader: string;
  whatsappPopupMsg: string;
  primaryColor: string;
  channels: Array<{
    id: string;
    enabled: boolean;
    phone: string;
    presetMessage: string;
    agentName: string;
    agentAvatar: string;
  }>;
}

interface WhatsAppPopupProps {
  config: WidgetConfig;
  serviceName: string | null;
  onClose: () => void;
}

export function WhatsAppPopup({ config, serviceName, onClose }: WhatsAppPopupProps) {
  const defaultMsg = serviceName
    ? `Hi! I have a question about your ${serviceName} service.`
    : "Hi! I have a question about your services.";
  const baseMessage = config.whatsappPopupMsg
    ? (serviceName
        ? config.whatsappPopupMsg.replace("{service}", serviceName)
        : config.whatsappPopupMsg)
    : defaultMsg;
  const [message, setMessage] = useState(baseMessage);
  const whatsappChannel = config.channels.find((c) => c.id === "whatsapp");

  const phone = whatsappChannel?.phone?.replace(/[^0-9]/g, "") || "";

  const sendMessage = () => {
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(message)}`;
    window.open(url, "_blank", "noopener,noreferrer");
    trackEvent("contact_click", {
      method: "whatsapp",
      location: "whatsapp_popup",
      label: serviceName || "general_inquiry",
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[10000] flex items-center justify-center bg-black/50">
      <div
        className="bg-white rounded-2xl shadow-2xl w-[360px] overflow-hidden animate-in fade-in zoom-in-95"
        style={{ fontFamily: "system-ui, -apple-system, sans-serif" }}
      >
        <div
          className="px-5 py-4 text-white text-center relative"
          style={{ backgroundColor: config.primaryColor }}
        >
          <button
            onClick={onClose}
            className="absolute top-3 right-3 text-white/80 hover:text-white"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
          <div className="flex items-center justify-center gap-2 mb-1">
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
          </div>
          <h3 className="font-semibold text-lg">{config.whatsappPopupHeader || "Chat with us on WhatsApp"}</h3>
          {whatsappChannel?.agentName && (
            <p className="text-sm opacity-90 mt-1">{whatsappChannel.agentName}</p>
          )}
        </div>

        <div className="p-5 space-y-4">
          <div className="bg-green-50 border border-green-200 rounded-xl p-3">
            <p className="text-sm text-green-800">
              Hi there! 👋 How can we help you?
              {serviceName && (
                <span className="block mt-1 font-medium">
                  You&apos;re inquiring about: {serviceName}
                </span>
              )}
            </p>
          </div>

          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Type your message..."
            rows={4}
            className="w-full border border-gray-200 rounded-xl px-4 py-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          />

          <button
            onClick={sendMessage}
            className="w-full py-3 rounded-xl text-white font-semibold text-sm transition-all hover:opacity-90 active:scale-[0.98]"
            style={{ backgroundColor: config.primaryColor }}
          >
            Continue to Chat
          </button>

          <p className="text-xs text-center text-gray-400">
            Opens in WhatsApp
          </p>
        </div>
      </div>
    </div>
  );
}
