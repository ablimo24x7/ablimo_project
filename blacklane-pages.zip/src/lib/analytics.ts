import { sendGAEvent } from "@next/third-parties/google";

export type ContactMethod =
  | "whatsapp"
  | "phone"
  | "email"
  | "messenger"
  | "telegram"
  | "viber"
  | "sms"
  | "other";

export type AnalyticsEventMap = {
  cta_click: {
    label: string;
    section: string;
    href: string;
  };
  contact_click: {
    method: ContactMethod;
    location: string;
    label: string;
  };
  lead_captured: {
    form_id: string;
    form_location: string;
  };
};

export const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GA_ID ?? "";

const IS_DEV = process.env.NODE_ENV === "development";
const IS_DEBUG = process.env.NEXT_PUBLIC_GA_DEBUG === "true";

const INTERNAL_PATHS = [/^\/dashboard/, /^\/auth/, /^\/invite/, /^\/api/];

export function isAnalyticsEnabled(): boolean {
  return GA_MEASUREMENT_ID.length > 0;
}

function isInternalPath(): boolean {
  if (typeof window === "undefined") return false;
  return INTERNAL_PATHS.some((pattern) => pattern.test(window.location.pathname));
}

export function trackEvent<K extends keyof AnalyticsEventMap>(
  event: K,
  params: AnalyticsEventMap[K]
): void {
  if (isInternalPath()) return;

  if (IS_DEV && !IS_DEBUG) {
    console.info("[analytics]", event, params);
    return;
  }

  if (!isAnalyticsEnabled()) return;

  sendGAEvent("event", event, params);
}

export function classifyContactMethod(href: string): ContactMethod | null {
  const value = href.trim().toLowerCase();
  if (!value) return null;
  if (value.startsWith("tel:")) return "phone";
  if (value.startsWith("mailto:")) return "email";
  if (value.startsWith("sms:")) return "sms";
  if (value.startsWith("viber:")) return "viber";
  if (value.includes("wa.me") || value.includes("whatsapp.com")) return "whatsapp";
  if (value.includes("m.me/") || value.includes("facebook.com/messenger")) return "messenger";
  if (value.includes("t.me/") || value.includes("telegram.me")) return "telegram";
  return null;
}
